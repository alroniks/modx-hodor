<?php

return 'Hodor!';