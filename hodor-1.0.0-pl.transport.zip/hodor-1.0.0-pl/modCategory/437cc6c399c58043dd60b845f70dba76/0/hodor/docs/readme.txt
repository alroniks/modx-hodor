--------------------
Hodor
--------------------
Author: Ivan Klimchuk <ivan@klimchuk.com>
--------------------

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/Alroniks/Hodor/issues